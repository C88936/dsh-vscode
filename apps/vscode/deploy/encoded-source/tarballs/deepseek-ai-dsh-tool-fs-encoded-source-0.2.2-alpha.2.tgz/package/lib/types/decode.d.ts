/**
 * Fatal decoding of workspace bytes under the configured encoding policy.
 *
 * Every path is decoded through a `fatal` decoder, so an invalid or truncated
 * byte sequence fails the read instead of turning into replacement characters.
 * {@link decodeBytes} applies the complete policy (BOM, rules, strict UTF-8,
 * then the restricted legacy fallback) because it holds the whole file;
 * {@link decodeStream} decides from the BOM or a rule alone and otherwise
 * requires strict UTF-8, because it may not rewind a consumed stream.
 *
 * `observed` reports whether the bytes were proven to be strict UTF-8. Only
 * such a read may record the `fs/observed` present observation that a later
 * write or edit guards against: a legacy decode is a read-only view.
 *
 * @module @deepseek-ai/dsh-tool-fs-encoded-source/decode
 */
import type { EncodingPolicy, LegacyEncoding, PolicyLocation, SourceEncoding } from './encoding-policy.ts';
/** One file decoded under the policy, with the encoding that produced its text. */
export interface DecodedSourceText {
    /** Decoded text, without a byte-order mark. */
    text: string;
    /** Encoding the bytes were decoded with. */
    encoding: SourceEncoding;
    /** Whether the file began with a byte-order mark. */
    hasBom: boolean;
    /** Whether the bytes were proven to be strict UTF-8 (with or without a BOM). */
    observed: boolean;
}
/** A streamed file whose encoding was decided before any text was emitted. */
export interface DecodedSourceStream {
    /** Encoding the chunks are decoded with. */
    encoding: SourceEncoding;
    /** Whether the file began with a byte-order mark. */
    hasBom: boolean;
    /** Whether the bytes are being proven strict UTF-8; only then may a read record a present observation. */
    observed: boolean;
    /** Decoded text chunks in file order. */
    chunks: AsyncIterable<string>;
}
/**
 * Whether one encoding is a legacy codepage rather than a UTF-8 form.
 * @param encoding - the resolved encoding to classify.
 * @returns whether the encoding is a legacy codepage.
 */
export declare function isLegacyEncoding(encoding: SourceEncoding): encoding is LegacyEncoding;
/**
 * Test whether a byte sequence is strict UTF-8.
 * @param bytes - the complete file bytes.
 * @returns whether a fatal UTF-8 decode accepts every byte.
 */
export declare function isStrictUtf8(bytes: Uint8Array): boolean;
/**
 * Decode one complete file under the configured policy.
 *
 * Resolution order is BOM, the first matching rule (which also overrides bytes
 * that happen to be valid UTF-8, because a rule is an explicit statement about
 * the file), strict UTF-8, then the restricted legacy fallback. Without a BOM,
 * rule, or admitting fallback an undecodable file fails as `FS_NOT_TEXT`.
 * @param bytes - the complete file bytes.
 * @param policy - the resolved encoding policy.
 * @param location - the file path and the session working directory.
 * @param displayPath - the path the model named, used in failure messages.
 * @returns the decoded text, its encoding, and whether it was proven UTF-8.
 * @throws {FsError} `FS_NOT_TEXT` when no configured encoding accepts the bytes.
 */
export declare function decodeBytes(bytes: Uint8Array, policy: EncodingPolicy, location: PolicyLocation, displayPath: string): DecodedSourceText;
/**
 * Decode a streamed file, deciding its encoding from its first bytes.
 *
 * Only a BOM or a matching rule can name a legacy codepage here; every other
 * stream is decoded as fatal UTF-8, because a stream cannot be rewound after
 * the fallback's precondition (a failed UTF-8 decode) is discovered. A file
 * that needs a legacy fallback must therefore be read whole, which the read
 * tool does below its streaming threshold.
 * @param source - byte chunks in file order.
 * @param policy - the resolved encoding policy.
 * @param location - the file path and the session working directory.
 * @param displayPath - the path the model named, used in failure messages.
 * @returns the decided encoding and the decoded text chunks.
 */
export declare function decodeStream(source: AsyncIterable<Uint8Array>, policy: EncodingPolicy, location: PolicyLocation, displayPath: string): Promise<DecodedSourceStream>;
//# sourceMappingURL=decode.d.ts.map