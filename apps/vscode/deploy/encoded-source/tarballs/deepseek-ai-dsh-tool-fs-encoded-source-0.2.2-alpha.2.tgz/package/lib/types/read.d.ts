/**
 * The model-facing `read` tool, byte-identical in arguments, output object,
 * envelope, caps, and card presentation to `@deepseek-ai/dsh-tool-fs`'s `read`,
 * but decoding through the configured encoding policy.
 *
 * The one deliberate difference is the observation: the `fs/observed` present
 * observation is emitted only when the bytes were proven strict UTF-8 (a UTF-8
 * BOM counts). A file decoded through a legacy codepage stays read-only,
 * because the write and edit guards treat an unobserved target as "create
 * only" and refuse to replace it.
 *
 * @module @deepseek-ai/dsh-tool-fs-encoded-source/read
 */
import type { Context } from '@deepseek-ai/cordis';
import type { FsInfo, FsTarget } from '@deepseek-ai/dsh-fs';
import type { ToolExecution } from '@deepseek-ai/dsh-tools';
import type { EncodingPolicy } from './encoding-policy.ts';
/** Resolved read-tool caps — plugin config after defaulting (see `Config`). */
export interface ReadToolCaps {
    /** Default and maximum number of lines returned by one call. */
    limit: number;
    /** Maximum characters returned for a single line. */
    maxLineLength: number;
    /** Maximum bytes returned for selected file lines. */
    maxBytes: number;
    /** Files at or above this size stream; smaller files read whole into memory. */
    streamMinSize: number;
}
/** Validated `read` arguments after defaulting. */
export interface ReadInput {
    filePath: string;
    offset: number;
    limit: number;
}
/**
 * Validate value constraints the schema DSL can't express. `maxLimit` is the deployment's line cap.
 * @param args - the schema-validated raw tool arguments; `offset`/`limit` must be positive integers when given.
 * @param maxLimit - the configured line cap: both the default `limit` and the largest one accepted.
 * @returns the validated input with `offset` defaulted to 1 and `limit` to `maxLimit`.
 */
export declare function parseReadArgs(args: {
    file_path: string;
    offset?: number;
    limit?: number;
}, maxLimit: number): ReadInput;
/**
 * Resolve a model-supplied path, observe absence, and require a regular file.
 * @param ctx - the plugin context providing filesystem resolution and observation events.
 * @param exec - the current tool execution, including the owning Agent and cancellation.
 * @param requestedPath - the raw path supplied to the tool.
 * @returns the resolved target and its single stat result.
 * @throws {FsError} `FS_NOT_FOUND` for an absent target and `FS_NOT_REGULAR_FILE` for a non-file.
 */
export declare function resolveRegularReadTarget(ctx: Context, exec: ToolExecution, requestedPath: string): Promise<{
    target: FsTarget;
    info: FsInfo;
}>;
/**
 * Register the encoding-aware `read` tool and its scope-aware system-prompt guidance.
 * @param ctx - the plugin context; registrations are effects scoped to it, and execution uses its `fs` service.
 * @param caps - the deployment's resolved read caps.
 * @param policy - the deployment's resolved encoding policy.
 */
export declare function applyReadTool(ctx: Context, caps: ReadToolCaps, policy: EncodingPolicy): void;
//# sourceMappingURL=read.d.ts.map