/**
 * The encoding-aware replacement suite for a mixed legacy and UTF-8 workspace:
 * `read`, `grep`, and `glob` with the same names, arguments, results, caps, and
 * card presentation as the installed tools, plus a configured codepage policy.
 *
 * This is a function plugin (no default export). Mount it in place of
 * `@deepseek-ai/dsh-tool-fs`'s `read` (set that row's `read: false`) and of the
 * `@deepseek-ai/dsh-tool-fs-search` row, which it replaces entirely.
 *
 * @module @deepseek-ai/dsh-tool-fs-encoded-source
 */
import type { Context } from '@deepseek-ai/cordis';
import { Config } from './encoding-policy.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "tool-fs-encoded-source";
/** Services required by the replacement suite (`spillStore` stays optional, read through `ctx.get()`). */
export declare const inject: string[];
export { Config };
/**
 * Register the encoding-aware `read`, `grep`, and `glob` tools.
 *
 * Load-time validation covers every cap, the timer bound the subprocess seam
 * grants, and the encoding policy itself: a fallback entry that limits nothing
 * fails the load instead of decoding the whole workspace through one codepage.
 * @param ctx - plugin context; registrations are effects scoped to this plugin.
 * @param config - resolved plugin configuration from schemastery.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map