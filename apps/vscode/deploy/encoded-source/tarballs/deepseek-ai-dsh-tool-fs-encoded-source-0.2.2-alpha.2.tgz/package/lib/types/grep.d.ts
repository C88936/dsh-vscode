/**
 * The model-facing `grep` tool with encoding-aware candidate handling.
 *
 * A single ripgrep pass cannot match a Chinese pattern inside GBK bytes: the
 * pattern is UTF-8, and the file's bytes are not. The tool therefore keeps the
 * ordinary ripgrep pass over every candidate, enumerates the same candidates
 * with `rg --files` under the same path/include/ignore rules, resolves each
 * candidate's encoding with the shared policy, and re-searches a temporary
 * UTF-8 mirror of only the files that resolve to a legacy codepage. Paths are
 * mapped back to their workspace display form and de-duplicated by
 * `(path, lineNumber)`, preferring the decoded mirror text.
 *
 * Everything else is the installed `grep`: the same schema, argv builder,
 * `--json` parser, preview and match caps, grouping and formatting, complete
 * result spill, timeout, cancellation, and search-card metadata.
 *
 * @module @deepseek-ai/dsh-tool-fs-encoded-source/grep
 */
import type { Context } from '@deepseek-ai/cordis';
import type { GrepInput, GrepMatch, GrepToolCaps } from '@deepseek-ai/dsh-tool-fs-search';
import type { EncodingPolicy } from './encoding-policy.ts';
/**
 * The argv that lists the candidate files a search covers, under the same
 * path, include, and ignore rules as the search itself.
 * @param input - the validated `grep` arguments.
 * @returns the complete ripgrep argument vector (excluding the binary itself).
 */
export declare function buildCandidateCommand(input: GrepInput): string[];
/**
 * Merge the ordinary pass with the mirror pass, de-duplicating by
 * `(path, lineNumber)` and preferring the decoded mirror text for a match both
 * passes found.
 * @param base - matches from the ordinary pass, in output order.
 * @param mirror - matches from the mirror pass, in output order.
 * @returns the merged matches, keeping the ordinary pass's order.
 */
export declare function mergeMatches(base: readonly GrepMatch[], mirror: readonly GrepMatch[]): GrepMatch[];
/**
 * Register the encoding-aware `grep` tool and its scope-aware system-prompt guidance.
 * @param ctx - the plugin context; registrations are effects scoped to it, and execution uses its subprocess service.
 * @param caps - the deployment's resolved grep caps.
 * @param policy - the deployment's resolved encoding policy.
 * @param sourceMaxBytes - byte cap on one candidate read while resolving encodings.
 */
export declare function applyGrepTool(ctx: Context, caps: GrepToolCaps, policy: EncodingPolicy, sourceMaxBytes: number): void;
//# sourceMappingURL=grep.d.ts.map