/**
 * The deployment's encoding policy for workspace text: the ordered resolution
 * order BOM → configured per-file rule → strict UTF-8 → restricted legacy
 * fallback, plus every cap the three replacement tools apply.
 *
 * `Config` is the plugin's schemastery schema; {@link resolveEncodingPolicy}
 * turns its rules and fallbacks into the matcher the decoder consults. A rule
 * is an explicit statement about a path's codepage, so it also overrides a
 * byte sequence that happens to be valid UTF-8: an operator who declares
 * `*.cls` as GBK means it. The fallback is the only implicit choice, and it
 * applies only inside the configured directories or extensions.
 *
 * @module @deepseek-ai/dsh-tool-fs-encoded-source/encoding-policy
 */
import z from '@deepseek-ai/schemastery';
/**
 * One legacy codepage a file may be decoded through. `gbk` and `gb2312` both
 * decode with the GBK converter: GB2312 is a subset of GBK, and the platform
 * decoder named `gb2312` is that same converter.
 */
export type LegacyEncoding = 'gbk' | 'gb2312' | 'gb18030' | 'utf-16le' | 'utf-16be';
/** Every encoding a read may resolve to, including the two UTF-8 forms. */
export type SourceEncoding = 'utf-8' | 'utf-8-bom' | LegacyEncoding;
/** One ordered per-file rule: the first glob that matches a path decides its encoding. */
export interface SourceEncodingRule {
    /** Glob matched against the workdir-relative path, or the basename when it contains no `/`. */
    glob: string;
    /** Encoding this file's bytes are decoded with. */
    encoding: SourceEncoding;
    /** Only `decode` is defined: this package never writes legacy files. */
    mode: 'decode';
}
/**
 * One opt-in legacy fallback. It applies only when the strict UTF-8 decode
 * fails, and only to paths matching its `directories` or `extensions`; an
 * entry that names neither limits nothing and is rejected at load.
 */
export interface LegacyFallbackRule {
    /** Codepage the fallback decodes with. */
    encoding: LegacyEncoding;
    /** Directories the fallback is limited to, absolute or relative to the session working directory. Empty means "any directory this entry's extensions reach". */
    directories: string[];
    /** File suffixes (with the leading dot) the fallback is limited to. Empty means "any extension inside this entry's directories". */
    extensions: string[];
}
/** Plugin config: the encoding policy plus every read, grep, and glob cap. */
export interface Config {
    /** Whether an over-cap `glob` page is sampled across top-level entries; required so the ordering choice is explicit. */
    sampleOverCapGlobResults: boolean;
    /** Ordered per-file encoding rules. The first matching glob decides. */
    rules?: SourceEncodingRule[];
    /** Opt-in legacy codepage fallbacks, consulted only after strict UTF-8 fails. */
    fallback?: LegacyFallbackRule[];
    /** Max bytes of one file the grep mirror reads to resolve its encoding. */
    sourceMaxBytes?: number;
    /** Default and maximum number of lines returned by one `read` call. */
    readLimit?: number;
    /** Maximum characters returned for a single line before truncation. */
    readMaxLineLength?: number;
    /** Maximum bytes returned for the selected lines of one `read` call. */
    readMaxBytes?: number;
    /** Files at or above this size stream instead of loading whole into memory; streamed reads decode BOM, rules, or strict UTF-8 only. */
    readStreamMinSize?: number;
    /** Max paths one `glob` call retains inline. */
    globMaxResults?: number;
    /** Max flat matches one `grep` call retains inline. */
    grepMaxMatches?: number;
    /** Max bytes retained for one matched-line preview. */
    grepMaxLineBytes?: number;
    /** Max bytes of one search's serialized `presentationMeta`. */
    searchMetaMaxBytes?: number;
    /** Max complete raw `rg` stdout one search parses. */
    rawOutputMaxBytes?: number;
    /** Terminate-escalation grace (ms) handed to the subprocess seam. */
    graceMs?: number;
    /** Max bytes retained for one search's stderr tail. */
    stderrMaxBytes?: number;
    /** Cooperative tool-call budget (ms) on all three tools. */
    timeoutMs?: number;
}
/** Default cap on the bytes one grep candidate mirror reads (16 MiB). */
export declare const SOURCE_MAX_BYTES: number;
/** Default and maximum number of lines returned by one `read` call, mirroring `tool-fs`. */
export declare const READ_LIMIT = 2000;
/** Default maximum characters returned for a single read line, mirroring `tool-fs`. */
export declare const READ_MAX_LINE_LENGTH = 2000;
/** Default maximum bytes returned for the selected read lines, mirroring `tool-fs`. */
export declare const READ_MAX_BYTES: number;
/** Default streaming threshold, mirroring `tool-fs`: files at or above it stream. */
export declare const READ_STREAM_MIN_SIZE: number;
/** Default inline `glob` path cap, mirroring `tool-fs-search`. */
export declare const GLOB_MAX_RESULTS = 100;
/** Default inline `grep` match cap, mirroring `tool-fs-search`. */
export declare const GREP_MAX_MATCHES = 250;
/** Default per-line preview budget, mirroring `tool-fs-search`. */
export declare const GREP_MAX_LINE_BYTES = 2000;
/** Default serialized search-metadata budget, mirroring `tool-fs-search`. */
export declare const SEARCH_META_MAX_BYTES = 65536;
/** Default raw search-output budget, mirroring `tool-fs-search`. */
export declare const RAW_OUTPUT_MAX_BYTES = 20000000;
/** Default terminate-escalation grace, mirroring `tool-fs-search`. */
export declare const SEARCH_GRACE_MS = 3000;
/** Default stderr diagnostic-tail budget, mirroring `tool-fs-search`. */
export declare const SEARCH_STDERR_MAX_BYTES: number;
/** Default cooperative tool-call budget, mirroring `tool-fs-search`. */
export declare const SEARCH_TIMEOUT_MS = 30000;
/** Plugin config schema; every deployment-varying choice is a validated field. */
export declare const Config: z<Config>;
/** Where a path sits relative to the session working directory, for rule and fallback matching. */
export interface PolicyLocation {
    /** Absolute path of the file being decoded. */
    readonly filePath: string;
    /** Absolute session working directory the deployment's relative configuration resolves against. */
    readonly workdir: string;
}
/** One resolved, validated encoding policy. */
export interface EncodingPolicy {
    /** Rules in configured order, each with its compiled matcher. */
    readonly rules: readonly {
        readonly glob: string;
        readonly encoding: SourceEncoding;
        readonly matcher: RegExp;
    }[];
    /** Fallbacks in configured order, each with its directories resolved to absolute posix paths. */
    readonly fallback: readonly {
        readonly encoding: LegacyEncoding;
        readonly directories: readonly string[];
        readonly extensions: readonly string[];
    }[];
}
/** The BOM a byte prefix starts with. */
export interface BomDecision {
    /** Encoding the BOM declares. */
    readonly encoding: 'utf-8-bom' | 'utf-16le' | 'utf-16be';
    /** Bytes the BOM occupies. */
    readonly bytes: number;
}
/**
 * Resolve a file's BOM. A BOM wins over every configured rule: it is the only
 * statement the file itself makes about its codepage.
 * @param head - the first bytes of the file; fewer than three is still valid input.
 * @returns the declared encoding and its byte length, or `undefined` without a BOM.
 */
export declare function bomDecision(head: Uint8Array): BomDecision | undefined;
/** The number of bytes {@link bomDecision} needs to answer. */
export declare const BOM_BYTES = 3;
/**
 * Compile one glob into an anchored regular expression. Supported syntax is
 * `*` (within a path segment), `**` (across segments), `?` (one character),
 * and `{a,b}` (alternation); every other character is literal.
 * @param glob - the configured glob.
 * @returns the compiled expression, matched case-insensitively.
 */
export declare function compileGlob(glob: string): RegExp;
/**
 * Resolve and validate the configured policy. Fallback entries that name
 * neither a directory nor an extension would apply everywhere, which is what
 * the opt-in fallback exists to avoid, so they fail the plugin load instead of
 * silently widening.
 * @param config - the schema-validated plugin config.
 * @returns the resolved policy.
 * @throws when a rule names a blank glob or a fallback limits nothing.
 */
export declare function resolveEncodingPolicy(config: {
    rules?: readonly SourceEncodingRule[];
    fallback?: readonly LegacyFallbackRule[];
}): EncodingPolicy;
/**
 * Resolve the configured rule for one file.
 * @param policy - the resolved policy.
 * @param location - the file and the working directory.
 * @returns the declared encoding, or `undefined` when no rule matches.
 */
export declare function configuredEncoding(policy: EncodingPolicy, location: PolicyLocation): SourceEncoding | undefined;
/**
 * Resolve the configured legacy fallback for one file. A fallback applies when
 * every limit it declares admits the file: inside one of its directories, and
 * ending with one of its extensions.
 * @param policy - the resolved policy.
 * @param location - the file and the working directory.
 * @returns the fallback encoding, or `undefined` when no entry admits the file.
 */
export declare function fallbackEncoding(policy: EncodingPolicy, location: PolicyLocation): LegacyEncoding | undefined;
//# sourceMappingURL=encoding-policy.d.ts.map