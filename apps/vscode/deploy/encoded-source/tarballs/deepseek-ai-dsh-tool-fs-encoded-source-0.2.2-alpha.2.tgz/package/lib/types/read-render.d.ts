/**
 * Pure read presentation, mirroring `@deepseek-ai/dsh-tool-fs`'s `read-render`
 * module: turn decoded text into a bounded, line-numbered window and the same
 * model-facing envelope. The replacement read tool must render byte-identical
 * text and persisted metadata to the tool it replaces, so the windowing,
 * truncation, footer, language hint, and metadata narrowing are restated here
 * rather than reimplemented differently. Chunk scanning caps the current line,
 * so even one newline-free giant line cannot grow memory without bound.
 * @module @deepseek-ai/dsh-tool-fs-encoded-source/read-render
 */
/** Default maximum characters returned for a single line (the `readMaxLineLength` config). */
export declare const READ_MAX_LINE_LENGTH = 2000;
/** Default maximum bytes returned for selected file lines (the `readMaxBytes` config). */
export declare const READ_MAX_BYTES: number;
/** Resolved read window. The consumer applies its defaults/caps before calling. */
export interface ReadWindow {
    /** 1-based first line to return. */
    offset: number;
    /** Maximum number of lines to return. */
    limit: number;
    /** Maximum characters returned for a single line; overflow is truncated with a suffix. */
    maxLineLength: number;
    /** Maximum bytes of selected output; overflow stops the scan and marks `truncatedByBytes`. */
    maxBytes: number;
}
/** One line returned from a text file. */
export interface FileTextLine {
    /** 1-based line number in the file. */
    number: number;
    /** Line text without its trailing newline. */
    text: string;
}
/** The windowed result {@link buildWindow} produces from a file's decoded text. */
export interface WindowResult {
    /** Returned lines, already numbered. */
    lines: FileTextLine[];
    /** Exact total line count in the file. */
    totalLines: number;
    /** Whether selected output hit the byte cap. */
    truncatedByBytes: boolean;
}
/** Outcome of a bounded text read — what {@link formatReadOutput} renders. */
export interface FileReadOutcome {
    /** 1-based first line requested. */
    offset: number;
    /** Returned lines, already numbered. */
    lines: FileTextLine[];
    /** Exact total line count in the file. */
    totalLines: number;
    /** Whether selected output hit the byte cap. */
    truncatedByBytes?: true;
}
/**
 * Build one window from streamed or whole-file chunks, enforcing line and byte caps while still
 * scanning to an exact total line count, and throwing `FS_NOT_FOUND` when the requested offset is
 * past EOF.
 * @param chunks - decoded text chunks in file order; chunk boundaries carry no meaning.
 * @param request - the resolved window; the caller has already applied its defaults and caps.
 * @param displayPath - the caller-facing path used in the offset-out-of-range error.
 * @returns the numbered window lines, the total line count seen, and the byte-cap truncation flag.
 */
export declare function buildWindow(chunks: AsyncIterable<string> | Iterable<string>, request: ReadWindow, displayPath: string): Promise<WindowResult>;
/**
 * Format a read outcome as one line-numbered text block body.
 * @param displayPath - the backend-resolved path rendered in the envelope's `<path>` element.
 * @param outcome - the windowed read to render.
 * @returns the model-facing envelope: numbered lines plus a continuation or end-of-file footer.
 */
export declare function formatReadOutput(displayPath: string, outcome: FileReadOutcome): string;
/**
 * Derive the persisted `lang` hint from a read path's file extension. The
 * shared table in `@deepseek-ai/dsh-util-code-language` owns the recognized
 * suffixes, so the replacement read card keeps the exact hint a recorded
 * session already holds.
 */
export { readLangHintForPath as langFromPath } from '@deepseek-ai/dsh-util-code-language';
/**
 * The `read` tool's private `tool/result` `meta` payload: the structured
 * line-numbered window a capable UI renders as a code view. It is persisted
 * with the session log, so it must stay JSON-serializable and identical to the
 * tool this package replaces.
 */
export interface FsReadMeta {
    /** The read file's model-facing path. */
    path: string;
    /** The 1-based first line the window requested, kept even when `lines` is empty. */
    offset: number;
    /** The returned window's lines, each keeping its file line number. */
    lines: FileTextLine[];
    /** Exact total line count in the file. */
    totalLines: number;
    /** Syntax-highlighting language hint from the extension, or omitted for plain text. */
    lang?: string;
}
/**
 * Narrow opaque live or replayed result metadata to a structured read window.
 * Malformed or semantically invalid metadata returns `undefined` so
 * presentation can fall back to the generic text card instead of throwing
 * during replay.
 * @param meta - result metadata.
 * @returns the validated read window, or `undefined` for absent, malformed, or semantically invalid data.
 */
export declare function readMetaFromMeta(meta: unknown): FsReadMeta | undefined;
//# sourceMappingURL=read-render.d.ts.map